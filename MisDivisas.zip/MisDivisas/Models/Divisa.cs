﻿namespace MisDivisas.Models
{
    public class Divisa
    {
        public string Codigo { get; set; } // Ej: "USD"
        public string Nombre { get; set; } // Ej: "United States Dollar"
    }
}
