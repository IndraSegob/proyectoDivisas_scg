﻿namespace MisDivisas.Models
{
    public class ConversionDivisaViewModel
    {
        public string DivisaOrigen { get; set; }
        public string DivisaDestino { get; set; }
        public decimal Monto { get; set; }
        public decimal Resultado { get; set; }
        public Dictionary<string, string> DivisasDisponibles { get; set; } = new();
    }
}
