﻿namespace MisDivisas.Models
{
    public class GestionDivisasViewModel
    {
        public string DivisaPrincipal { get; set; }
        public List<string> Favoritas { get; set; } = new();
        public Dictionary<string, string> DivisasDisponibles { get; set; } = new();
    }
}
