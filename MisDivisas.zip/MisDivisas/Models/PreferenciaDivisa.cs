﻿namespace MisDivisas.Models
{
    public class PreferenciaDivisa
    {
        public int Id { get; set; }
        public string UsuarioId { get; set; } // Vinculado a Identity
        public string DivisaPrincipal { get; set; }
        public List<DivisaFavorita> DivisasFavoritas { get; set; } = new();
    }
}
