﻿namespace MisDivisas.Models
{
    public class TasasViewModel
    {
        public string DivisaPrincipal { get; set; }
        public Dictionary<string, decimal> Tasas { get; set; } = new();
        public string Fecha { get; set; }
    }
}
