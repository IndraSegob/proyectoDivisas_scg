﻿namespace MisDivisas.Models
{
    public class DivisaFavorita
    {
        public int Id { get; set; }
        public string CodigoDivisa { get; set; }
        public int PreferenciaDivisaId { get; set; }
        public PreferenciaDivisa PreferenciaDivisa { get; set; }
    }
}
