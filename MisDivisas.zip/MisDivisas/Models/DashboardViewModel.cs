﻿namespace MisDivisas.Models
{
    public class DashboardViewModel
    {
        public string DivisaPrincipal { get; set; }
        public string Fecha { get; set; }
        public Dictionary<string, decimal> TasasActuales { get; set; } = new();
        public Dictionary<string, decimal> Conversiones { get; set; } = new();
        public decimal MontoReferencia { get; set; } = 1; // Por defecto 1 unidad
    }
}
