﻿namespace MisDivisas.Models
{
    public class HistorialViewModel
    {
        public string DivisaPrincipal { get; set; }
        public DateTime FechaSeleccionada { get; set; }
        public Dictionary<string, decimal> Tasas { get; set; } = new();
    }
}
