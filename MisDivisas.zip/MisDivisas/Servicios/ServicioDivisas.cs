﻿using System.Net.Http;
using System.Text.Json;

namespace MisDivisas.Servicios
{
    public class ServicioDivisas:IServicioDivisas
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public ServicioDivisas(IHttpClientFactory httpClientFactory) 
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<Dictionary<string, string>> ObtenerCatalogoDivisasAsync()
        {
            var cliente = _httpClientFactory.CreateClient();
            var respuesta = await cliente.GetStringAsync("https://api.frankfurter.dev/v1/currencies");
            return JsonSerializer.Deserialize<Dictionary<string, string>>(respuesta);
        }

        public async Task<Dictionary<string, decimal>> ObtenerTasasActualesAsync(string baseDivisa, IEnumerable<string> favoritas)
        {
            var cliente = _httpClientFactory.CreateClient();
            var url = $"https://api.frankfurter.dev/v1/latest?base={baseDivisa}";
            var respuesta = await cliente.GetStringAsync(url);
            var json = JsonDocument.Parse(respuesta);

            return json.RootElement.GetProperty("rates")
                .EnumerateObject()
                .Where(r => favoritas.Contains(r.Name))
                .ToDictionary(r => r.Name, r => r.Value.GetDecimal());
        }

        public async Task<Dictionary<string, decimal>> ObtenerTasasPorFechaAsync(string baseDivisa, IEnumerable<string> favoritas, DateTime fecha)
        {
            var cliente = _httpClientFactory.CreateClient();
            var url = $"https://api.frankfurter.dev/v1/{fecha:yyyy-MM-dd}?base={baseDivisa}";
            var respuesta = await cliente.GetStringAsync(url);
            var json = JsonDocument.Parse(respuesta);

            return json.RootElement.GetProperty("rates")
                .EnumerateObject()
                .Where(r => favoritas.Contains(r.Name))
                .ToDictionary(r => r.Name, r => r.Value.GetDecimal());
        }

        public async Task<decimal> ConvertirAsync(string origen, string destino, decimal monto)
        {
            var cliente = _httpClientFactory.CreateClient();
            var url = $"https://api.frankfurter.dev/v1/latest?amount={monto}&from={origen}&to={destino}";
            var respuesta = await cliente.GetStringAsync(url);
            var json = JsonDocument.Parse(respuesta);
            return json.RootElement.GetProperty("rates").GetProperty(destino).GetDecimal();
        }


    }
}
