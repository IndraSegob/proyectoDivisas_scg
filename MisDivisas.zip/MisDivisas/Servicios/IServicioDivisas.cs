﻿namespace MisDivisas.Servicios
{
    public interface IServicioDivisas
    {
        Task<Dictionary<string, string>> ObtenerCatalogoDivisasAsync();
        Task<Dictionary<string, decimal>> ObtenerTasasActualesAsync(string baseDivisa, IEnumerable<string> favoritas);
        Task<Dictionary<string, decimal>> ObtenerTasasPorFechaAsync(string baseDivisa, IEnumerable<string> favoritas, DateTime fecha);
        Task<decimal> ConvertirAsync(string origen, string destino, decimal monto);
    }
}
