﻿using MisDivisas.Models;

namespace MisDivisas.Repositorio
{
    public interface IRepositorioDivisas
    {
        Task GuardarPreferenciasAsync(PreferenciaDivisa preferencias);
        Task<PreferenciaDivisa> ObtenerPreferenciasAsync(string usuarioId);
    }
}
