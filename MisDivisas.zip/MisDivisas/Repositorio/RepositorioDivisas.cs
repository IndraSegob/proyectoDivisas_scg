﻿using Microsoft.EntityFrameworkCore;
using MisDivisas.Models;

namespace MisDivisas.Repositorio
{
    public class RepositorioDivisas:IRepositorioDivisas
    {
        private readonly ApplicationDbContext _context;

        public RepositorioDivisas(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<PreferenciaDivisa> ObtenerPreferenciasAsync(string usuarioId)
        {
            return await _context.PreferenciasDivisas
                .Include(p => p.DivisasFavoritas)
                .FirstOrDefaultAsync(p => p.UsuarioId == usuarioId);
        }

        public async Task GuardarPreferenciasAsync(PreferenciaDivisa preferencias)
        {
            _context.Update(preferencias);
            await _context.SaveChangesAsync();
        }
    }
}
