﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using MisDivisas.Models;

namespace MisDivisas
{
    public class ApplicationDbContext:IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions options):base(options)
        {
                
        }

        public DbSet<PreferenciaDivisa> PreferenciasDivisas { get; set; }
        public DbSet<DivisaFavorita> DivisasFavoritas { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<DivisaFavorita>()
                .HasOne(f => f.PreferenciaDivisa)
                .WithMany(p => p.DivisasFavoritas)
                .HasForeignKey(f => f.PreferenciaDivisaId);
        }
    }
}
