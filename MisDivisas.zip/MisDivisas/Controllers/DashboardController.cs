﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MisDivisas.Models;
using MisDivisas.Repositorio;
using MisDivisas.Servicios;

namespace MisDivisas.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        private readonly IRepositorioDivisas _repositorio;
        private readonly IServicioDivisas _servicioDivisas;
        private readonly UserManager<IdentityUser> _userManager;

        public DashboardController(IRepositorioDivisas repositorio, IServicioDivisas servicioDivisas, UserManager<IdentityUser> userManager)
        {
            _repositorio = repositorio;
            _servicioDivisas = servicioDivisas;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var usuarioId = _userManager.GetUserId(User);
            var preferencias = await _repositorio.ObtenerPreferenciasAsync(usuarioId);

            var favoritas = preferencias.DivisasFavoritas.Select(f => f.CodigoDivisa);
            var tasas = await _servicioDivisas.ObtenerTasasActualesAsync(preferencias.DivisaPrincipal, favoritas);

            var modelo = new DashboardViewModel
            {
                DivisaPrincipal = preferencias.DivisaPrincipal,
                Fecha = DateTime.Today.ToString("yyyy-MM-dd"),
                TasasActuales = tasas,
                Conversiones = tasas.ToDictionary(kvp => kvp.Key, kvp => kvp.Value * 1)
            };

            return View(modelo);
        }
    }
}
