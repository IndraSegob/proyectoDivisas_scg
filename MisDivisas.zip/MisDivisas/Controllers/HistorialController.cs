﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MisDivisas.Models;
using MisDivisas.Repositorio;
using MisDivisas.Servicios;
using System.Net.Http;
using System.Text.Json;

namespace MisDivisas.Controllers
{
    [Authorize]
    public class HistorialController : Controller
    {
        private readonly IRepositorioDivisas _repositorio;
        private readonly IServicioDivisas _servicioDivisas;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IHttpClientFactory _httpClientFactory;

        public HistorialController(IRepositorioDivisas repositorio, IServicioDivisas servicioDivisas, UserManager<IdentityUser> userManager, IHttpClientFactory httpClientFactory)
        {
            _repositorio = repositorio;
            _servicioDivisas = servicioDivisas;
            _userManager = userManager;
            _httpClientFactory = httpClientFactory;
        }

        public IActionResult SeleccionarFecha()
        {
            return View(new HistorialViewModel { FechaSeleccionada = DateTime.Today });
        }

        [HttpPost]
        public async Task<IActionResult> VerHistorial(HistorialViewModel modelo)
        {
            var usuarioId = _userManager.GetUserId(User);
            var preferencias = await _repositorio.ObtenerPreferenciasAsync(usuarioId);
            var favoritas = preferencias.DivisasFavoritas.Select(f => f.CodigoDivisa);

            var tasas = await _servicioDivisas.ObtenerTasasPorFechaAsync(preferencias.DivisaPrincipal, favoritas, modelo.FechaSeleccionada);

            var resultado = new HistorialViewModel
            {
                DivisaPrincipal = preferencias.DivisaPrincipal,
                FechaSeleccionada = modelo.FechaSeleccionada,
                Tasas = tasas
            };

            return View("Resultado", resultado);
        }

        public IActionResult Consultar() => View();

        [HttpPost]
        public async Task<IActionResult> Consultar(string fecha, string baseDivisa)
        {
            var cliente = _httpClientFactory.CreateClient();
            var url = $"https://api.frankfurter.dev/v1/{fecha}?base={baseDivisa}";
            var respuesta = await cliente.GetStringAsync(url);
            var json = JsonDocument.Parse(respuesta);

            var tasas = json.RootElement.GetProperty("rates")
                .EnumerateObject()
                .ToDictionary(r => r.Name, r => r.Value.GetDecimal());

            ViewBag.Fecha = fecha;
            ViewBag.Base = baseDivisa;
            return View("Resultado", tasas);
        }
    }

}
