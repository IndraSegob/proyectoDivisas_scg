﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MisDivisas.Models;
using MisDivisas.Servicios;

namespace MisDivisas.Controllers
{
    [Authorize]
    public class ConversionController : Controller
    {
        private readonly IServicioDivisas _servicioDivisas;

        public ConversionController(IServicioDivisas servicioDivisas)
        {
            _servicioDivisas = servicioDivisas;
        }

        public async Task<IActionResult> Convertir()
        {
            var divisas = await _servicioDivisas.ObtenerCatalogoDivisasAsync();
            return View(new ConversionDivisaViewModel { DivisasDisponibles = divisas });
        }

        [HttpPost]
        public async Task<IActionResult> Convertir(ConversionDivisaViewModel modelo)
        {
            modelo.Resultado = await _servicioDivisas.ConvertirAsync(modelo.DivisaOrigen, modelo.DivisaDestino, modelo.Monto);
            modelo.DivisasDisponibles = await _servicioDivisas.ObtenerCatalogoDivisasAsync();
            return View(modelo);
        }
    }
}
