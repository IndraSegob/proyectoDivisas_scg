﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MisDivisas.Models;
using MisDivisas.Repositorio;
using System.Text.Json;

namespace MisDivisas.Controllers
{
    [Authorize]
    public class TasasController : Controller
    {
        private readonly IRepositorioDivisas _repositorio;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly UserManager<IdentityUser> _userManager;

        public TasasController(IRepositorioDivisas repositorio, IHttpClientFactory httpClientFactory, UserManager<IdentityUser> userManager)
        {
            _repositorio = repositorio;
            _httpClientFactory = httpClientFactory;
            _userManager = userManager;
        }

        public async Task<IActionResult> Ver()
        {
            var usuarioId = _userManager.GetUserId(User);
            var preferencias = await _repositorio.ObtenerPreferenciasAsync(usuarioId);
            var cliente = _httpClientFactory.CreateClient();

            var url = $"https://api.frankfurter.dev/v1/latest?base={preferencias.DivisaPrincipal}";
            var respuesta = await cliente.GetStringAsync(url);
            var json = JsonDocument.Parse(respuesta);

            var tasas = json.RootElement.GetProperty("rates")
                .EnumerateObject()
                .Where(r => preferencias.DivisasFavoritas.Any(f => f.CodigoDivisa == r.Name))
                .ToDictionary(r => r.Name, r => r.Value.GetDecimal());

            var modelo = new TasasViewModel
            {
                DivisaPrincipal = preferencias.DivisaPrincipal,
                Tasas = tasas,
                Fecha = json.RootElement.GetProperty("date").GetString()
            };

            return View(modelo);
        }
    }
}
