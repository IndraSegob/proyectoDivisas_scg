﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MisDivisas.Models;
using MisDivisas.Repositorio;
using MisDivisas.Servicios;

namespace MisDivisas.Controllers
{
    [Authorize]
    public class DivisasController : Controller
    {
        private readonly IRepositorioDivisas _repositorio;
        private readonly IServicioDivisas _servicioDivisas;
        private readonly UserManager<IdentityUser> _userManager;

        public DivisasController(IRepositorioDivisas repositorio, IServicioDivisas servicioDivisas, UserManager<IdentityUser> userManager)
        {
            _repositorio = repositorio;
            _servicioDivisas = servicioDivisas;
            _userManager = userManager;
        }
        [HttpGet]
        public async Task<IActionResult> Gestionar()
        {
            var usuarioId = _userManager.GetUserId(User);
            var preferencias = await _repositorio.ObtenerPreferenciasAsync(usuarioId);
            var divisas = await _servicioDivisas.ObtenerCatalogoDivisasAsync();

            var modelo = new GestionDivisasViewModel
            {
                DivisasDisponibles = divisas,
                DivisaPrincipal = preferencias?.DivisaPrincipal,
                Favoritas = preferencias?.DivisasFavoritas.Select(f => f.CodigoDivisa).ToList() ?? new()
            };

            return View(modelo);
        }

        [HttpPost]
        public async Task<IActionResult> Guardar(GestionDivisasViewModel modelo)
        {
            var usuarioId = _userManager.GetUserId(User);
            var preferencias = await _repositorio.ObtenerPreferenciasAsync(usuarioId) ?? new PreferenciaDivisa { UsuarioId = usuarioId };

            preferencias.DivisaPrincipal = modelo.DivisaPrincipal;
            preferencias.DivisasFavoritas = modelo.Favoritas.Select(c => new DivisaFavorita { CodigoDivisa = c }).ToList();

            await _repositorio.GuardarPreferenciasAsync(preferencias);
            return RedirectToAction("Index", "Home");
        }
    }
}
